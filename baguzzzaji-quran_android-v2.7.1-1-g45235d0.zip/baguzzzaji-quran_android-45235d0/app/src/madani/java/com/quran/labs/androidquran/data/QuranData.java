package com.quran.labs.androidquran.data;

public class QuranData extends BaseQuranData {

}
