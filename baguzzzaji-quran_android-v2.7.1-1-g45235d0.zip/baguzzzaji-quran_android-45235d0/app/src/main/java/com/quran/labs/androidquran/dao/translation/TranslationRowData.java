package com.quran.labs.androidquran.dao.translation;

public interface TranslationRowData {
  String name();
  boolean isSeparator();
  boolean needsUpgrade();
}
